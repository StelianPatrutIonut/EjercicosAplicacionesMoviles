package com.example.ballgame


import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.SurfaceHolder
import android.view.SurfaceView

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    //HILO DEL JUEGO
    private lateinit var gameThread: Thread
    //BOOLEANO CON EL ESTADO DEL JUEGO (JUGANDO O NO)
    private var playing = false
    //CARACTERIZACIÓN DE LA BOLA
    private val ballPaint = Paint()
    //CARACTERIZACIÓN DEL SQUARE
    private val squarePaint = Paint()
    //OBJETO BOLA
    private var ball1: Ball? = null
    //TAMAÑO DE CADA SQUARE
    private val squareSize = 40f
    //CONJUNTO DE SQUARES
    private var squares: Array<Array<String>>? = null

    /* init{}
    ES UNA ESPECIE DE CONSTRUCTOR, PERO CON OTROS MATICES.
    https://stackoverflow.com/questions/55356837/what-is-the-difference-between-init-block-and-constructor-in-kotlin
    PODREMOS INICIALIZAR LA BOLA Y EL “SQUARE” QUE HABREMOS DEFINIDO COMO OBJETOS DE LA CLASE PAINT() USANDO LA CLASE COLOR()
     */
    init {
        holder.addCallback(this)
        //Asignar color a ball y square

        ballPaint.color = Color.BLACK
        squarePaint.color = Color.WHITE

    }
    /* run()
    SERÁ UN MÉTODO QUE SE EJECUTARÁ DE FORMA “INFINITA” HASTA QUE OCURRA ALGO EN EL JUEGO
    -->> ¿QUE PUEDE OCURRIR EN UNA INTERFAZ COMO LA QUE HABÉIS VISTO?. <<--
    PODREMOS DEFINIR ALGÚN TIPO DE VARIABLE BOOLEANA (PLAYING POR EJEMPLO).
    LLAMAREMOS DE FORMA ININTERRUMPIDA A LOS MÉTODOS UPDATE(), DRAW() Y CONTROL().
    */
    override fun run() {
        while (playing) {
            update()
            draw()
            control()
        }
    }
    /* update()
    ACTUALIZARÁ LA POSICIÓN DE CADA UNA DE LAS BOLAS DE LA PANTALLA.
    ESPECIAL ATENCIÓN A LAS VARIABLES "FANTASMA" width y height.
    -->> ¿QUE MÁS COSAS PODRÍA ACTUALIZAR ESTA FUNCION UPDATE?
     */
    private fun update() {
        ball1?.updatePosition()
    }

    /* draw()
    EN CASO DE QUE EL "HOLDER SURFACE" (SOPORTE DE SUPERFICIE) CONSTRUIDO SEA CORRECTO,
    PINTA LOS SQUARES Y LA BOLA MEDIANTE CANVAS.
    BLOQUEO Y DESBLOQUEO MIENTRAS SE PINTA.
     */
    private fun draw() {
        if (holder.surface.isValid) {
            val canvas = holder.lockCanvas()
            drawSquares(canvas)
            ball1?.let { drawBall(canvas, it) }
            holder.unlockCanvasAndPost(canvas)
        }
    }
    /* control()
    ¿QUE OS PUEDO CONTAR YO DE THREADS QUE NO OS HAYA CONTADO DIEGO? :-)
     */
    private fun control() {
        try {
            Thread.sleep(17) // Aproximadamente 60 FPS
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
    }

    /* drawBall()
        PINTAMOS UN CIRCULO CON LAS CARACTERÍSTICAS DE LA BOLA (QUIEN PINTA ES LA CLASE CANVA)
    */
    private fun drawBall(canvas: Canvas, ball: Ball) {
        //RELLENAR
    }

    /* drawSquares()
        PINTAMOS RECTÁNGULOS ¿EN UNA MATRIZ?
        ESTAMOS RELLENANDO EL "CONJUNTO DE SQUARES" QUE DEFINIMOS AL PRINCIPIO
     */
    private fun drawSquares(canvas: Canvas) {
        squares?.let { squaresArray ->
            for (i in squaresArray.indices) {
                for (j in squaresArray[i].indices) {

                    canvas.drawRect(
                        i * squareSize,
                        j * squareSize,
                        (i + 1) * squareSize,
                        (j + 1) * squareSize,
                        squarePaint
                    )
                }
            }
        }
    }
    /* pause()
       EN CASO DE PAUSAR EL JUEGO POR ALGUNA RAZÓN EXTERNA, YA QUE NO HAY BOTON DE PAUSA (DE MOMENTO)
     */
    fun pause() {
        playing = false
        gameThread.join()
    }

    /* resume()
        EN CASO DE REANUDAR EL JUEGO, TRAS ALGÚN SUCESO O EVENTO EXTERNO.
    */
    fun resume() {
        playing = true
        gameThread = Thread(this)
        gameThread.start()
    }

    /* DEFINIERMOS UNA INNER CLASS:
    https://wiki.yowu.dev/es/Knowledge-base/Kotlin/Learning/043-nested-and-inner-classes-in-kotlin-creating-classes-within-classes
    ¿CUALES SON LOS ATRIBUTOS DE LA INNER CLASS?

    ESTA CLASE TIENE UN ÚNICO MÉTODO QUE ACTUALIZA LA POSICIÓN DE LA BOLA Y COMPRUEBA SI HAY COLISIÓN.
    */
    inner class Ball(var x: Float, var y: Float, var dx: Float = 5f, var dy: Float = 5f) {
        val radius = squareSize / 2

        fun updatePosition() {
            //RELLENAR
        }
    }
    /* checkCollision(Ball)
        EN CASO DE COLISIÓN, DEBEMOS CAMBIAR EL SENTIDO DE LA BOLA
        TENEMOS QUE TENER CLARO QUE LA BOLA PUEDE REBOTAR ARRIBA, ABAJO, IZQUIERDA Y DERECHA,
        ES DECIR, EJE X E Y.
        ADEMÁS LA BOLA AL REBOTAR, NO DEBERÍA DEJAR DE VERSE.
     */
    private fun checkCollision(ball: Ball) {
         //RELLENAR
    }

    /* surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int)
       IMPLEMENTACIÓN OPCIONAL SI ES NECESARIO MANEJAR CAMBIOS EN LA SUPERFICIE

     */
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {

    }
    /* surfaceCreated(holder: SurfaceHolder)
       SE UBICA-POSICIONA EL OBJETO BOLA, SE INICIALIZAN LOS "SQUARES" Y ARRANCA EL JUEGO
    */
    override fun surfaceCreated(holder: SurfaceHolder) {
        //RELLENAR
        //RELLENAR
        resume() // Comenzar el juego cuando la superficie esté creada
    }
    /* surfaceDestroyed(holder: SurfaceHolder)
       EN CASO DE QUE LA SUPERFICIE SEA DESTRUIDA POR UN FACTOR EXTERNO
    */
    override fun surfaceDestroyed(holder: SurfaceHolder) {
        pause() // Pausar el juego cuando la superficie sea destruida
    }

    /* initializeSquares(width: Int, height: Int)
    SE INICIALIZAN LOS "SQUARES" (MATRIZ DE SQUARES) EN FUNCIÓN DEL WIDTH Y EL HEIGHT
     */
    private fun initializeSquares(width: Int, height: Int) {
        val numSquaresX = (width / squareSize).toInt()
        val numSquaresY = (height / squareSize).toInt()
        squares = Array(numSquaresX) { Array(numSquaresY) { "WHITE" } }
    }
}
